<?php
session_start();
$_SESSION["menu"] = "about";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Best CSE Engineering Colleges in Hyderabad | NNRG </title>
    <meta name="description" content="NNRG is among the best CSE Engineering Colleges in Hyderabad. We offer high quality, in-depth education in computer science engineering with expert faculty guidance.">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="computer science and engineering college, best engineering colleges for cse, best engineering colleges in hyderabad for cse, top cse engineering colleges in telangana, bachelor's degree in computer science">
    <link rel="icon" href="images/HEAD.png" type="image/x-icon">
    <link rel="stylesheet" href="css/grid.css">
    
    <script src="js/jquery.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <link rel="stylesheet" href="css/style.css"><!--[if lt IE 9]>
    <html class="lt-ie9">
      <div style="clear: both; text-align:center; position: relative;"><a href="http://windows.microsoft.com/en-US/internet-explorer/.."><img src="images/ie8-panel/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    </html>
    <script src="js/html5shiv.js"></script><![endif]-->
    <script src="js/device.min.js"></script>
  <?php include 'gtag.php' ?>   </head>
  <body>
    <div class="page">
      <!--
      ========================================================
      							HEADER
      ========================================================
      
       
      -->
      <?php include 'header.php' ?>
      <!--
      ========================================================
                                  CONTENT
      ========================================================
      -->
      <main class="mobile-center">
        <section class="well">
		 <div class="container">
		<img src="images/cse/banners/cse_lab.jpg"  height="100px" border="0" alt="">
            </div>
			 </section>
        		
        <section class="well1">
          <div class="container">
            <div class="row">
              <div class="grid_3" id="slide">
              
                    <?php include 'csemenu.php' ?>
                
              </div>
              <div class="grid_9">
			  <div class="clearfix" id="about">
                <h3 STYLE="text-shadow: 1px 1px gray;font-size:22px;COLOR:#AC3B61;">Frequently Asked Questions-</h3><br>

                <p align="justify"><font size="5" color="#AC3B61">&#x261B;</font><strong> How many systems and other major equipment are available in each lab in the CSE Department?</strong></p>

                <p align="justify" style="margin-left:6%">NNRG is ranked among one of the best engineering colleges in Hyderabad for CSE. Our CSE Department comprises seven computer labs with more than 400 high-end systems with software’s recommended by JNTUH and AICTE. Apart from that, the department has 6 computer centers for UG students and 1 Elite Research and Development center apart from labs provided for other branches.</p><br>


                <p align="justify"><font size="5" color="#AC3B61">&#x261B;</font><strong> What are the placement opportunities for computer science engineering students in NNRG?</strong></p><br>

                <p align="justify" style="margin-left:6%">NNRG provides its students with 100% placement assistance which has helped students to successfully get placed in some of the top companies like Infosys, HCL, Capgemini, etc. The college organizes in-campus interviews for student placement and training, conducts guest lectures, and facilitates industry interaction. Placement of students in reputed organizations is a major focus of the university making it one of the top CSE engineering colleges in Telangana.</p><br>

                <p align="justify"><font size="5" color="#AC3B61">&#x261B;</font><strong> How to choose the best engineering college for CSE?</strong></p><br>

                <p align="justify" style="margin-left:6%">Choosing the best engineering college for CSE is a difficult task. Therefore, thorough research is very important before making the decision. There are various colleges offering Bachelor’s degree in Computer Science but to choose the best one you need to consider some points like the scope of the curriculum, the faculties, the kind of technologies and laboratories present in the college, the infrastructure, the co-curricular activities and placement cell and opportunities in order to help you equip with the industry and be future ready.</p><br>

                <p align="justify" style="margin-left:6%">Speaking of which, NNRG is one such college that is one of the best engineering colleges in Hyderabad for CSE that offers a Bachelor’s degree in Computer Science as well as in postgraduate levels. Our college is packed with highly qualified faculties, best-in-class infrastructure, industrial workshops, and college events and is well recognized in the region. With a legacy of 13 years and an excellent placement record, our college can become your desired checkpoint for a great career ahead.</p><br>

                <p align="justify"><font size="5" color="#AC3B61">&#x261B;</font><strong>Can I get a seat in NNRG through JEE Mains?</strong></p><br>

                <p align="justify" style="margin-left:6%"> Yes, it is possible to get a seat in NNRG through JEE Mains.</p><br>

                <p align="justify"><font size="5" color="#AC3B61">&#x261B;</font><strong>Name major companies visited for campus placement for CSE Branch in NNRG, in the recent past.</strong></p><br>

                <p align="justify" style="margin-left:6%">NNRG provides the top-class Bachelor’s degree in Computer Science to its students and is ranked as one of the best engineering colleges in Hyderabad for CSE. Some of the major companies visited for campus placement for CSE Branch in NNRG, in the recent past are:</p><br>

                <p align="justify" style="margin-left:6%">What is the qualification of faculty members in the Computer Science & Engineering Department at NNRG?</p><br>

                <p align="justify" style="margin-left:6%">The HOD of the Computer Science & Engineering Department at NNRG, DR. K. Rameshwaraiah holds B.Tech (CSE) and M.S. (CSE) Degrees. He is also a Ph.D. holder from the U.K. His area of specialization is Software Engineering and he has a teaching experience of 12 years. In addition, all the professors, assistant professors, and associate professors have years of teaching experience and are highly qualified with B.Tech and M.Tech degrees and Ph.D. degrees from some of the best engineering colleges for CSE.</p><br>

              </div>
			  </div>
              </div>
          </div>
        </section>

		<section class="well1">
          <div class="container">
            
            <div class="row">
                <div class="grid_3"></div>
			<div class="grid_9">
			    <h2 class="mobile-center"><font size="" color="#AC3B61"><center>ROLL OF HONOR</center></font></h2>
			    <?php $x = 0;?>
			    <table class="wow fadeInUp">
                  <tr align="center">
				  <td>S.No </td>
                    <td>Batch </td>
					<td>Roll No </td>
                    <td>Name of the Student</td>
                    <td>CGPA/Percentage</td>
                  </tr>
                   <tr align="center">
				  <td><?php $x++; echo $x; ?></td>
                    <td>2017-21</td>
					<td>177Z1A0533</td>
                    <td>J Anusha</td>
                    <td>8.22</td>
                  </tr>
                 <tr align="center">
				  <td><?php $x++; echo $x; ?></td>
                    <td>2016-20</td>
					<td>167Z1A0571</td>
                    <td>M. Sushmitha</td>
                    <td>8.41</td>
                  </tr>
                  <tr align="center">
				  <td><?php $x++; echo $x; ?></td>
                    <td>2015-19</td>
					<td>157Z1A0546</td>
                    <td>G. Meghana</td>
                    <td>74.97%</td>
                  </tr>
                  <tr align="center">
				  <td><?php $x++; echo $x; ?></td>
                    <td>2014-18</td>
					<td>147Z1A0507</td>
                    <td>K. Navya Reddy</td>
                    <td>70.7%</td>
                  </tr>
				  <tr align="center">
				  <td><?php $x++; echo $x; ?></td>
                    <td>2013-17</td>
					<td>137Z1A05B2</td>
                    <td>V. Sarika</td>
                    <td>76.38%</td>
                  </tr>
				  <tr align="center">
				  <td><?php $x++; echo $x; ?></td>
                    <td>2012-16</td>
					<td>127Z1A0562</td>
                    <td>P. Sai Reetika</td>
                    <td>79.98%</td>
                  </tr>
				  <tr align="center">
				  <td><?php $x++; echo $x; ?></td>
                    <td>2011-15</td>
					<td>117Z1A0576</td>
                    <td>P. Ashwini</td>
                    <td>80.55%</td>
                  </tr>
				  <tr align="center">
				  <td><?php $x++; echo $x; ?></td>
                    <td>2010-14</td>
					<td>107Z1A0589</td>
                    <td>R. Meena</td>
                    <td>80.88%</td>
                  </tr>
                  <tr align="center">
					<td><?php $x++; echo $x; ?></td>
                    <td>2009-13</td>
					<td>097Z1A0536</td>
                    <td>N. Vinay Reddy</td>
                    <td>79.1%</td>
                  </tr>
                </table>
              </div>
              
            </div>
          </div>
        </section>
		<section class="well1">
          <div class="container">
            <h2 class="mobile-center"><font size="" color="#AC3B61"><center>TOPPERS</center></font></h2>
            <div class="row">
			  <div class="grid_4">
			      
			    <table class="wow fadeInUp">
			        <caption><strong>II-Year-I Semester</strong></caption>
                  <tr align="center" style="font-weight: bold; ">
                    <td>Roll No</td>
                    <td>Name</td>
                    <td>SGPA</td>
                  </tr>
                  <tr><td>207Z1A0510</td><td>B D S V Prakash</td><td>9.30</td></tr>
 <tr><td>207Z1A05H2</td><td>Urelli Preethi</td><td>9.30</td></tr>
 <tr><td>207Z1A0560</td><td>Jai Kishan Gehlot</td><td>9.20</td></tr>
 <tr><td>207Z1A05H1</td><td>Tummidi Jyothirmai</td><td>9.20</td></tr>
 <tr><td>207Z1A0553</td><td>G Reethika Reddy</td><td>9.00</td></tr>
                                   
                </table>
              </div>
              <div class="grid_4">
                <table data-wow-delay="0.2s" class="wow fadeInUp">
                     <caption><strong>III-Year-I Semester</strong></caption>
                  <tr align="center" style="font-weight: bold; ">
                    <td>Roll No</td>
                    <td>Name</td>
                    <td>SGPA</td>
                  </tr>
                  <tr><td>197Z1A0571</td><td>K Jayasree</td><td>8.45</td></tr>
 <tr><td>197Z1A0540</td><td>D Ankitha</td><td>8.45</td></tr>
 <tr><td>197Z1A0518</td><td>B Sainath</td><td>8.18</td></tr>
 <tr><td>197Z1A0521</td><td>B Geeta Sree</td><td>8.18</td></tr>
 <tr><td>197Z1A0522</td><td>Bhoomika M</td><td>8.18</td></tr>

                </table>
              </div>
               <div class="grid_4">
                <table data-wow-delay="0.4s" class="wow fadeInUp">
                     <caption><strong>IV-Year-II Semester</strong></caption>
                  <tr align="center" style="font-weight: bold; ">
                    <td>Roll No</td>
                    <td>Name</td>
                    <td>SGPA</td>
                  </tr>   
<tr><td>187Z1A0510</td><td>A Keerthi Bharathi</td><td>8.50</td></tr>
 <tr><td>187Z1A0518</td><td>Billapati Lavanya</td><td>8.50</td></tr>
 <tr><td>187Z1A0540</td><td>Ginjala Sreeja Reddy</td><td>8.50</td></tr>
 <tr><td>187Z1A0543</td><td>Goulikar Akhila</td><td>8.50</td></tr>
                </table>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <!--
      ========================================================
                                  FOOTER
      ========================================================
      -->
     <?php include 'footer.php' ?>
    </div>
    <script src="js/script.min.js"></script>
  </body>
</html>